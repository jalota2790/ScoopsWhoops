﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
public class ScoopSpawner : MonoBehaviour
{
    public float width;
    public float delay;

    public GameObject prefab;

    Coroutine coroutine;

    public void Begin()
    {
        coroutine = StartCoroutine(StartSpawn());
    }

    public void Stop()
    {
        if (coroutine != null) StopCoroutine(coroutine);
    }

    IEnumerator StartSpawn()
    {
        while (true)
        {
            yield return new WaitForSeconds(delay);
            Scoop scoop = Instantiate(prefab).GetComponent<Scoop>();
            scoop.transform.position = GetRandomPosition();
            scoop.speed = GameController.instance.currentSpeed;
            scoop.isFalling = true;
        }
    }

    Vector3 GetRandomPosition()
    {
        return new Vector3(Random.Range(-width, width), transform.position.y);
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.DrawWireCube(transform.position, new Vector3(width * 2, 0.5f));
    }
}
