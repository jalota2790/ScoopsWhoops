﻿using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class ObjectPool : MonoBehaviour
{
    public GameObject obj;
    public int count;

    public List<GameObject> objects;
    public List<GameObject> objectsInUse;

    void Start()
    {
        objects = new List<GameObject>();
        objectsInUse = new List<GameObject>();

        for (int i = 0; i < count; i++)
        {
            GameObject obj = Instantiate(this.obj);
            objects.Add(obj);
            obj.SetActive(false);
        }
    }

    public GameObject GetObject()
    {
        if (objects.Count > 0)
        {
            GameObject obj = objects[0];
            objects.Remove(obj);
            objectsInUse.Add(obj);
            obj.GetComponent<PooledObject>().Enable();
            return obj;
        }
        else
        {
            GameObject obj = objectsInUse[0];
            objectsInUse.Remove(obj);
            objectsInUse.Add(obj);
            obj.GetComponent<PooledObject>().Enable();
            return obj;
        }
    }         
}


public class PooledObject : MonoBehaviour
{
    public virtual void Enable()
    {
        gameObject.SetActive(true);
    }

    public virtual void Disable()
    {
        gameObject.SetActive(false);
    }
}
